# Kepler's Laws Test

A little tool I made for simulating Kepler's 3rd law

## Screenshot

![Screenshot](/release/screenshot5.png)

## Controls

**Move Mouse**: Change radius of planets

**Backspace**: Reset planet positions

**Plus**: Add another planet

**Minus**: Remove a planet
